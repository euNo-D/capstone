﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace ILAGAN_Management_System
{
    public class SqlDbConnection
    {
        private SqlConnection db;

        public SqlDbConnection()
        {
            db = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan2;Integrated Security=True");
        }

        public SqlConnection GetConnection()
        {
            return db;
        }
        public void Open()
        {
            if (db.State == System.Data.ConnectionState.Closed)
            {
                db.Open();
            }
        }

        public void Close()
        {
            if (db.State == System.Data.ConnectionState.Open)
            {
                db.Close();
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ManageUserStatus : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler UpdateStatus;

        public ManageUserStatus()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadStatusOptions();
        }

        private void LoadStatusOptions()
        {
            try
            {
                db.Open();
                cmb_Status.Items.Clear();
                string query = "SELECT StatusName FROM UserStatus";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cmb_Status.Items.Add(reader["StatusName"].ToString());
                }

                cmb_Status.DropDownStyle = ComboBoxStyle.DropDownList;
                cmb_Status.FormattingEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading statuses: " + ex.Message);
            }
            finally
            {
                if (db.State == System.Data.ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private void btn_UpdateStatus_Click(object sender, EventArgs e)
        {
             try
            {
                db.Open();
                string query = "UPDATE Users SET StatusID = (SELECT StatusID FROM UserStatus WHERE StatusName = @Status) WHERE Username = @Username";
                SqlCommand command = new SqlCommand(query, db);

                command.Parameters.AddWithValue("@Status", cmb_Status.Text);
                command.Parameters.AddWithValue("@Username", txtUsername.Text);

                int result = command.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("User status updated successfully.");
                    UpdateStatus.Invoke(this, EventArgs.Empty);
                }
                else
                {
                    MessageBox.Show("User not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating the status: " + ex.Message);
            }
            finally
            {
                if (db.State == System.Data.ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }
    }
}

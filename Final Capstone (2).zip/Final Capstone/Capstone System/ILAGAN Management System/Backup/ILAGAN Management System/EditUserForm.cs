﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class EditUserForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler UserUpdated;
        public event EventHandler UserDelete;

        public EditUserForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void EditUserForm_Load(object sender, EventArgs e)
        {

        }

        private void txtUsername_Leave_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtUsername.Text))
            {
                try
                {
                    db.Open();
                    string query = @"SELECT Password, FirstName, LastName, Contact_No FROM Users WHERE Username = @Username";
                    SqlCommand command = new SqlCommand(query, db);
                    command.Parameters.AddWithValue("@Username", txtUsername.Text);

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        txtPassword.Text = reader["Password"].ToString();
                        txtFName.Text = reader["FirstName"].ToString();
                        txtLastName.Text = reader["LastName"].ToString();
                        txtPhoneNumber.Text = reader["Contact_No"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("User not found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearUserFields();
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while fetching user details: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    db.Close();
                }
            }
        }

        private void ClearUserFields()
        {
            txtPassword.Clear();
            txtFName.Clear();
            txtLastName.Clear();
            txtPhoneNumber.Clear();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text) ||
                string.IsNullOrEmpty(txtFName.Text) || string.IsNullOrEmpty(txtLastName.Text) ||
                string.IsNullOrEmpty(txtPhoneNumber.Text))
            {
                MessageBox.Show("All fields must be filled.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            db.Open();
            string queryUpdate = @"UPDATE Users SET Password = @Password, FirstName = @FirstName, LastName = @LastName, Contact_No = @Contact_No WHERE Username = @Username";
            SqlCommand command = new SqlCommand(queryUpdate, db);
            command.Parameters.AddWithValue("@Username", txtUsername.Text);
            command.Parameters.AddWithValue("@Password", txtPassword.Text);
            command.Parameters.AddWithValue("@FirstName", txtFName.Text);
            command.Parameters.AddWithValue("@LastName", txtLastName.Text);
            command.Parameters.AddWithValue("@Contact_No", txtPhoneNumber.Text);

            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("User details updated successfully.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                UserUpdated.Invoke(this, EventArgs.Empty);
            }
            else
            {
                MessageBox.Show("Update failed. User not found.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
 

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            // Validate that all required text fields are filled
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text) ||
                string.IsNullOrEmpty(txtFName.Text) || string.IsNullOrEmpty(txtLastName.Text) ||
                string.IsNullOrEmpty(txtPhoneNumber.Text))
            {
                MessageBox.Show("Textbox must be filled up to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Confirm deletion with the user
            DialogResult deleteresult = MessageBox.Show("Are you sure you want to delete this user?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (deleteresult == DialogResult.Yes)
            {
                try
                {
                    // Open the database connection
                    db.Open();

                    // Delete the user from the Users table based on the username
                    string queryDeleteUser = @"DELETE FROM Users WHERE Username = @Username";
                    using (SqlCommand commandUser = new SqlCommand(queryDeleteUser, db))
                    {
                        // Add the parameter to the query
                        commandUser.Parameters.AddWithValue("@Username", txtUsername.Text);

                        // Execute the query and check if a row was affected (deleted)
                        int result = commandUser.ExecuteNonQuery();

                        if (result > 0)
                        {
                            // If deletion was successful, display a success message
                            MessageBox.Show("User deleted successfully.", "Delete Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearUserFields();  // Clear user input fields
                            txtUsername.Clear();  // Clear the username text box
                            UserDelete.Invoke(this, EventArgs.Empty);  // Optionally invoke an event after deletion
                        }
                        else
                        {
                            // If no rows were affected, it means the user was not found
                            MessageBox.Show("Delete failed! User not found.", "Delete Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle any errors that occur during the deletion
                    MessageBox.Show("An error occurred while deleting the user: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Ensure the database connection is closed after the operation
                    if (db.State == ConnectionState.Open)
                    {
                        db.Close();
                    }
                }
            }
        }
    }
}
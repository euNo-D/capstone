﻿namespace ILAGAN_Management_System
{
    partial class ReleaseEquipmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lbl_Location = new System.Windows.Forms.Label();
            this.dgv_EquipmentsReleasedisplay = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_Release = new ILAGAN_Management_System.RoundedButton();
            this.cmb_Employees = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_EquipmentsReleasedisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(424, 68);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Release Equipment";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(22, 107);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 16);
            this.label12.TabIndex = 81;
            this.label12.Text = "Employee:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(22, 143);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(111, 16);
            this.label24.TabIndex = 197;
            this.label24.Text = "Service Location: ";
            // 
            // lbl_Location
            // 
            this.lbl_Location.AutoSize = true;
            this.lbl_Location.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Location.Location = new System.Drawing.Point(136, 141);
            this.lbl_Location.Name = "lbl_Location";
            this.lbl_Location.Size = new System.Drawing.Size(188, 18);
            this.lbl_Location.TabIndex = 199;
            this.lbl_Location.Text = "____________________";
            // 
            // dgv_EquipmentsReleasedisplay
            // 
            this.dgv_EquipmentsReleasedisplay.AllowUserToAddRows = false;
            this.dgv_EquipmentsReleasedisplay.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_EquipmentsReleasedisplay.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_EquipmentsReleasedisplay.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_EquipmentsReleasedisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_EquipmentsReleasedisplay.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_EquipmentsReleasedisplay.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_EquipmentsReleasedisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_EquipmentsReleasedisplay.Location = new System.Drawing.Point(25, 208);
            this.dgv_EquipmentsReleasedisplay.Name = "dgv_EquipmentsReleasedisplay";
            this.dgv_EquipmentsReleasedisplay.ReadOnly = true;
            this.dgv_EquipmentsReleasedisplay.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_EquipmentsReleasedisplay.RowHeadersVisible = false;
            this.dgv_EquipmentsReleasedisplay.Size = new System.Drawing.Size(370, 238);
            this.dgv_EquipmentsReleasedisplay.TabIndex = 263;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SeaGreen;
            this.label7.Location = new System.Drawing.Point(22, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 16);
            this.label7.TabIndex = 267;
            this.label7.Text = "Equipment:";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DimGray;
            this.panel4.Location = new System.Drawing.Point(25, 200);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(370, 2);
            this.panel4.TabIndex = 266;
            // 
            // btn_Release
            // 
            this.btn_Release.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Release.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Release.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Release.BorderRadius = 5;
            this.btn_Release.BorderSize = 0;
            this.btn_Release.FlatAppearance.BorderSize = 0;
            this.btn_Release.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Release.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Release.ForeColor = System.Drawing.Color.White;
            this.btn_Release.Location = new System.Drawing.Point(325, 452);
            this.btn_Release.Name = "btn_Release";
            this.btn_Release.Size = new System.Drawing.Size(70, 30);
            this.btn_Release.TabIndex = 268;
            this.btn_Release.Text = "Release";
            this.btn_Release.TextColor = System.Drawing.Color.White;
            this.btn_Release.UseVisualStyleBackColor = false;
            this.btn_Release.Click += new System.EventHandler(this.btn_Release_Click);
            // 
            // cmb_Employees
            // 
            this.cmb_Employees.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Employees.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Employees.FormattingEnabled = true;
            this.cmb_Employees.Location = new System.Drawing.Point(139, 102);
            this.cmb_Employees.Name = "cmb_Employees";
            this.cmb_Employees.Size = new System.Drawing.Size(233, 26);
            this.cmb_Employees.TabIndex = 82;
            // 
            // ReleaseEquipmentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(424, 494);
            this.Controls.Add(this.btn_Release);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.dgv_EquipmentsReleasedisplay);
            this.Controls.Add(this.lbl_Location);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.cmb_Employees);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.panel1);
            this.Name = "ReleaseEquipmentForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReleaseEquipmentForm";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_EquipmentsReleasedisplay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lbl_Location;
        private System.Windows.Forms.DataGridView dgv_EquipmentsReleasedisplay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel4;
        private RoundedButton btn_Release;
        private System.Windows.Forms.ComboBox cmb_Employees;

    }
}
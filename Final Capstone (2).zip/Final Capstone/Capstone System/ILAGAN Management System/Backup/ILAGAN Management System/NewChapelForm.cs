﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class NewChapelForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public NewChapelForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadChapelList();
        }
        private void LoadChapelList()
        {
            try
            {
                string query = "SELECT ChapelID, ChapelName, Capacity, Location, Price FROM Chapel";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dtChapelList = new DataTable();
                adapter.Fill(dtChapelList);

                // Bind data to DataGridView
                dgv_ChapelList.DataSource = dtChapelList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading chapel list: " + ex.Message);
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            // Check if all fields are filled
            if (string.IsNullOrEmpty(txt_ChapelName.Text) || string.IsNullOrEmpty(txt_Capacity.Text) ||
                string.IsNullOrEmpty(txt_Location.Text) || string.IsNullOrEmpty(txt_Price.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                string chapelName = txt_ChapelName.Text;
                int capacity = int.Parse(txt_Capacity.Text);
                string location = txt_Location.Text;
                decimal price = decimal.Parse(txt_Price.Text);

                // SQL insert query
                string insertQuery = "INSERT INTO Chapel (ChapelName, Capacity, Location, Price) " +
                                     "VALUES (@ChapelName, @Capacity, @Location, @Price)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@ChapelName", chapelName);
                    command.Parameters.AddWithValue("@Capacity", capacity);
                    command.Parameters.AddWithValue("@Location", location);
                    command.Parameters.AddWithValue("@Price", price);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Chapel added successfully.");
                        LoadChapelList(); // Refresh the chapel list
                    }
                    else
                    {
                        MessageBox.Show("Error adding chapel.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (dgv_ChapelList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a chapel to update.");
                return;
            }

            // Check if all fields are filled
            if (string.IsNullOrEmpty(txt_ChapelName.Text) || string.IsNullOrEmpty(txt_Capacity.Text) ||
                string.IsNullOrEmpty(txt_Location.Text) || string.IsNullOrEmpty(txt_Price.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get the selected chapel ID from the DataGridView
                int chapelId = Convert.ToInt32(dgv_ChapelList.SelectedRows[0].Cells["ChapelID"].Value);
                string chapelName = txt_ChapelName.Text;
                int capacity = int.Parse(txt_Capacity.Text);
                string location = txt_Location.Text;
                decimal price = decimal.Parse(txt_Price.Text);

                // SQL update query
                string updateQuery = "UPDATE Chapel SET ChapelName = @ChapelName, Capacity = @Capacity, " +
                                     "Location = @Location, Price = @Price WHERE ChapelID = @ChapelID";

                using (SqlCommand command = new SqlCommand(updateQuery, db))
                {
                    command.Parameters.AddWithValue("@ChapelName", chapelName);
                    command.Parameters.AddWithValue("@Capacity", capacity);
                    command.Parameters.AddWithValue("@Location", location);
                    command.Parameters.AddWithValue("@Price", price);
                    command.Parameters.AddWithValue("@ChapelID", chapelId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Chapel updated successfully.");
                        LoadChapelList(); // Refresh the chapel list
                    }
                    else
                    {
                        MessageBox.Show("Error updating chapel.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_ChapelList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a chapel to delete.");
                return;
            }

            try
            {
                // Get the selected chapel ID from the DataGridView
                int chapelId = Convert.ToInt32(dgv_ChapelList.SelectedRows[0].Cells["ChapelID"].Value);

                // SQL delete query
                string deleteQuery = "DELETE FROM Chapel WHERE ChapelID = @ChapelID";

                using (SqlCommand command = new SqlCommand(deleteQuery, db))
                {
                    command.Parameters.AddWithValue("@ChapelID", chapelId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Chapel deleted successfully.");
                        LoadChapelList(); // Refresh the chapel list
                    }
                    else
                    {
                        MessageBox.Show("Error deleting chapel.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dgv_ChapelList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_ChapelList.Rows[e.RowIndex];
                txt_ChapelName.Text = row.Cells["ChapelName"].Value.ToString();
                txt_Capacity.Text = row.Cells["Capacity"].Value.ToString();
                txt_Location.Text = row.Cells["Location"].Value.ToString();
                txt_Price.Text = row.Cells["Price"].Value.ToString();
            }
        }
    }
}

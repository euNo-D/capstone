﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class Chapel_Service : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        private int clientID;
        private string clientName;
        
        public int ReservationID { get; private set; }
        public decimal pricechap { get; private set; }


        public Chapel_Service(int clientId, string name, int reservationID )
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadReservations();
            LoadChapel();
            this.clientID = clientId;
            this.clientName = name;
            if (reservationID != 0)
            {
                MessageBox.Show("Loading reservation details for ID: " + reservationID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.ReservationID = reservationID;
                LoadReservationDetails(this.ReservationID); 
            }

        }
        private void LoadReservationDetails(int reservationId)
        {
            string query = @"SELECT cr.ChapelID, cr.StartDate, cr.EndDate, c.Price 
                             FROM ChapelReservation cr
                             JOIN Chapel c ON cr.ChapelID = c.ChapelID 
                             WHERE cr.ReservationID = @ReservationID";

            
            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@ReservationID", reservationId);
                try
                {
                    db.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        cmb_Chapel.SelectedValue = reader["ChapelID"];
                        dtp_StartDate.Value = reader.GetDateTime(reader.GetOrdinal("StartDate"));
                        dtp_EndDate.Value = reader.GetDateTime(reader.GetOrdinal("EndDate"));
                        lbl_Price.Text = ((decimal)reader["Price"]).ToString("F2");
                    }
                    else
                    {
                        MessageBox.Show("Reservation not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading reservation details: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }

        private void LoadChapel()
        {
            cmb_Chapel.Items.Clear();

            string query = "SELECT ChapelID, ChapelName, Price FROM Chapel";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable playlistsTable = new DataTable();
                adapter.Fill(playlistsTable);

                cmb_Chapel.DataSource = playlistsTable;
                cmb_Chapel.DisplayMember = "ChapelName";
                cmb_Chapel.ValueMember = "ChapelID";

                cmb_Chapel.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading playlists: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void cmb_Chapel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Chapel.SelectedItem != null)
            {
                DataRowView selectedChapel = (DataRowView)cmb_Chapel.SelectedItem;
                decimal price = Convert.ToDecimal(selectedChapel["Price"]);
                decimal totalPrice = CalculateTotalPrice(price);

                lbl_Price.Text = totalPrice.ToString("F2");

                pricechap = totalPrice;

            }
            else
            {
                lbl_Price.Text = "";
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (cmb_Chapel == null || cmb_Chapel.SelectedValue == null)
            {
                MessageBox.Show("Please select a chapel.", "Chapel Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidDateRange() || !validation())
            {
                return; 
            }

            int chapelId = (int)cmb_Chapel.SelectedValue;
            if (ReservationID == 0)
            {

                if (CheckForExistingReservations(chapelId, dtp_StartDate.Value, dtp_EndDate.Value))
                {
                    MessageBox.Show("The selected dates conflict with an existing reservation.", "Conflict Detected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var confirmResult = MessageBox.Show("Are you sure you want to save this chapel reservation?",
                                             "Confirm Save",
                                             MessageBoxButtons.YesNo,
                                             MessageBoxIcon.Question);
                if (confirmResult == DialogResult.Yes)
                {
                    SaveChapelReservation(chapelId);
                }
            }
            else
            {
                var confirmResult = MessageBox.Show("Are you sure you want to update this chapel reservation?",
                                             "Confirm Update",
                                             MessageBoxButtons.YesNo,
                                             MessageBoxIcon.Question);
                if (confirmResult == DialogResult.Yes)
                {
                    UpdateChapelReservation(chapelId);
                }
            }
        }
        //to insert database
        private void SaveChapelReservation(int chapelId)
        {
            string query = @"INSERT INTO ChapelReservation (ChapelID, ClientID, ReservationStatusID, StartDate, EndDate, ReservedBy)
                                                            VALUES 
                                                            (@ChapelID, @ClientID, @ReservationStatusID, @StartDate, @EndDate, @ReservedBy);
                                                            SELECT SCOPE_IDENTITY();";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@ChapelID", chapelId);
                command.Parameters.AddWithValue("@ClientID", clientID);
                command.Parameters.AddWithValue("@ReservationStatusID", 1);
                command.Parameters.AddWithValue("@StartDate", dtp_StartDate.Value);
                command.Parameters.AddWithValue("@EndDate", dtp_EndDate.Value);
                command.Parameters.AddWithValue("@ReservedBy", clientName);

                try
                {
                    db.Open();
                    ReservationID = Convert.ToInt32(command.ExecuteScalar());
                    MessageBox.Show("Chapel reservation saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.DialogResult = DialogResult.OK;
                    this.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving chapel reservation: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        //for update
        private void UpdateChapelReservation(int chapelId)
        {
            string query = @"UPDATE ChapelReservation SET ChapelID = @ChapelID,  StartDate = @StartDate, EndDate = @EndDate, ReservedBy = @ReservedBy
                             WHERE ReservationID = @ReservationID";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@ChapelID", chapelId);
                command.Parameters.AddWithValue("@StartDate", dtp_StartDate.Value);
                command.Parameters.AddWithValue("@EndDate", dtp_EndDate.Value);
                command.Parameters.AddWithValue("@ReservedBy", clientName);
                command.Parameters.AddWithValue("@ReservationID", ReservationID);

                try
                {
                    db.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Chapel reservation updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating chapel reservation: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        private bool CheckForExistingReservations(int chapelId, DateTime startDate, DateTime endDate)
        {
            string query = @"SELECT COUNT(*) FROM ChapelReservation 
                             WHERE ChapelID = @ChapelID 
                             AND ReservationStatusID IN (1, 2) 
                             AND ((StartDate <= @EndDate) AND (EndDate >= @StartDate))";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@ChapelID", chapelId);
                command.Parameters.AddWithValue("@StartDate", startDate);
                command.Parameters.AddWithValue("@EndDate", endDate);

                try
                {
                    db.Open();
                    int count = (int)command.ExecuteScalar();
                    return count > 0; // Return true if there are overlapping reservations for the same chapel
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error checking existing reservations: " + ex.Message);
                    return false; // Assume no conflict on error
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        private void dtp_StartDate_CloseUp(object sender, EventArgs e)
        {
            if (cmb_Chapel == null || cmb_Chapel.SelectedValue == null)
            {
                MessageBox.Show("Please select a chapel.", "Chapel Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int chapelId = (int)cmb_Chapel.SelectedValue;
            IsValidDateRange();
            if (CheckForExistingReservations(chapelId, dtp_StartDate.Value, dtp_EndDate.Value))
            {
                MessageBox.Show("The selected dates conflict with an existing reservation.", "Conflict Detected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        private void dtp_EndDate_CloseUp(object sender, EventArgs e)
        {
            if (cmb_Chapel == null || cmb_Chapel.SelectedValue == null)
            {
                MessageBox.Show("Please select a chapel.", "Chapel Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int chapelId = (int)cmb_Chapel.SelectedValue;
            IsValidDateRange();
            if (CheckForExistingReservations(chapelId, dtp_StartDate.Value, dtp_EndDate.Value))
            {
                MessageBox.Show("The selected dates conflict with an existing reservation.", "Conflict Detected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
        private decimal CalculateTotalPrice(decimal pricePerDay)
        {
            int numberOfDays = (dtp_EndDate.Value.Date - dtp_StartDate.Value.Date).Days;

            if (numberOfDays < 1)
            {
                return 0;
            }

            // Calculate the total price based on the number of days and price per day
            decimal totalPrice = pricePerDay * numberOfDays;
            return totalPrice;
        }

        private bool IsValidDateRange()
        {
            bool isValid = true;

            // Start date validations
            if (dtp_StartDate.Value.Date < DateTime.Today)
            {
                MessageBox.Show("Start date cannot be in the past.", "Invalid Start Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                isValid = false;
            }
            
            else if (dtp_StartDate.Value.Date == dtp_EndDate.Value.Date)
            {
                MessageBox.Show("Start date cannot be the same as the end date.", "Invalid Dates", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                isValid = false;
            }

            // End date validations
            if (dtp_EndDate.Value.Date < dtp_StartDate.Value.Date)
            {
                MessageBox.Show("End date cannot be earlier than the start date.", "Invalid End Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                isValid = false;
            }

            return isValid;
        }
        private bool validation()
        {
            bool isValid = true;
            if (dtp_StartDate.Value.Date > DateTime.Today.AddYears(1))
            {
                MessageBox.Show("Reservations cannot be made more than one year in advance.", "Invalid Start Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                isValid = false;
            }
            else if ((dtp_EndDate.Value.Date - dtp_StartDate.Value.Date).Days > 30)
            {
                MessageBox.Show("The reservation period cannot exceed one month.", "Invalid Duration", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                isValid = false;
            }
            return isValid;
        }
        private void LoadReservations()
        {
            string query = @"SELECT  c.ChapelName AS Chapel, cr.StartDate AS StartDate, 
                                    cr.EndDate AS EndDate, rs.StatusName AS Status
                             FROM ChapelReservation cr
                             JOIN Chapel c ON cr.ChapelID = c.ChapelID
                             JOIN ReservationStatus rs ON cr.ReservationStatusID = rs.ReservationStatusID
                             WHERE rs.ReservationStatusID IN (1, 2)"; 

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable reservationsTable = new DataTable();
                adapter.Fill(reservationsTable);

                dgv_Reservations.DataSource = reservationsTable;

                dgv_Reservations.Columns["Chapel"].HeaderText = "Chapel Name";
                dgv_Reservations.Columns["StartDate"].HeaderText = "Start Date";
                dgv_Reservations.Columns["EndDate"].HeaderText = "End Date";
                dgv_Reservations.Columns["Status"].HeaderText = "Status";

                dgv_Reservations.Columns["StartDate"].DefaultCellStyle.Format = "MMMM/d/yyyy";
                dgv_Reservations.Columns["EndDate"].DefaultCellStyle.Format = "MMMM/d/yyyy";    
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading reservations: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}

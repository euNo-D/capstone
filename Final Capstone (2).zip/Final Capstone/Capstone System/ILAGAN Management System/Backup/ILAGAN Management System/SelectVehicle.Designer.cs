﻿namespace ILAGAN_Management_System
{
    partial class SelectVehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_VehiclePrice = new System.Windows.Forms.Label();
            this.lbl_VehicleName = new System.Windows.Forms.Label();
            this.las = new System.Windows.Forms.Label();
            this.asd = new System.Windows.Forms.Label();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.picbox_VehicleImage = new System.Windows.Forms.PictureBox();
            this.dgv_VehicleRecords = new System.Windows.Forms.DataGridView();
            this.btnSelect = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_VehicleImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_VehicleRecords)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(836, 68);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Select Vehicle";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_VehiclePrice
            // 
            this.lbl_VehiclePrice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_VehiclePrice.AutoSize = true;
            this.lbl_VehiclePrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.lbl_VehiclePrice.Location = new System.Drawing.Point(637, 252);
            this.lbl_VehiclePrice.Name = "lbl_VehiclePrice";
            this.lbl_VehiclePrice.Size = new System.Drawing.Size(75, 15);
            this.lbl_VehiclePrice.TabIndex = 101;
            this.lbl_VehiclePrice.Text = "-----------------";
            // 
            // lbl_VehicleName
            // 
            this.lbl_VehicleName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_VehicleName.AutoSize = true;
            this.lbl_VehicleName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.lbl_VehicleName.Location = new System.Drawing.Point(637, 214);
            this.lbl_VehicleName.Name = "lbl_VehicleName";
            this.lbl_VehicleName.Size = new System.Drawing.Size(75, 15);
            this.lbl_VehicleName.TabIndex = 100;
            this.lbl_VehicleName.Text = "-----------------";
            // 
            // las
            // 
            this.las.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.las.AutoSize = true;
            this.las.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.las.Location = new System.Drawing.Point(512, 252);
            this.las.Name = "las";
            this.las.Size = new System.Drawing.Size(46, 15);
            this.las.TabIndex = 99;
            this.las.Text = "Price:";
            // 
            // asd
            // 
            this.asd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.asd.AutoSize = true;
            this.asd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.asd.Location = new System.Drawing.Point(512, 214);
            this.asd.Name = "asd";
            this.asd.Size = new System.Drawing.Size(101, 15);
            this.asd.TabIndex = 98;
            this.asd.Text = "Vehicle Name:";
            // 
            // txt_search
            // 
            this.txt_search.AccessibleName = "";
            this.txt_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(22, 76);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(172, 24);
            this.txt_search.TabIndex = 95;
            this.txt_search.Tag = "";
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // picbox_VehicleImage
            // 
            this.picbox_VehicleImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.picbox_VehicleImage.Location = new System.Drawing.Point(640, 76);
            this.picbox_VehicleImage.Name = "picbox_VehicleImage";
            this.picbox_VehicleImage.Size = new System.Drawing.Size(147, 108);
            this.picbox_VehicleImage.TabIndex = 97;
            this.picbox_VehicleImage.TabStop = false;
            // 
            // dgv_VehicleRecords
            // 
            this.dgv_VehicleRecords.AllowUserToAddRows = false;
            this.dgv_VehicleRecords.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_VehicleRecords.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_VehicleRecords.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_VehicleRecords.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_VehicleRecords.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_VehicleRecords.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_VehicleRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_VehicleRecords.Location = new System.Drawing.Point(22, 106);
            this.dgv_VehicleRecords.Name = "dgv_VehicleRecords";
            this.dgv_VehicleRecords.ReadOnly = true;
            this.dgv_VehicleRecords.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_VehicleRecords.RowHeadersVisible = false;
            this.dgv_VehicleRecords.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_VehicleRecords.Size = new System.Drawing.Size(471, 208);
            this.dgv_VehicleRecords.TabIndex = 166;
            this.dgv_VehicleRecords.DoubleClick += new System.EventHandler(this.dgv_VehicleRecords_DoubleClick);
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnSelect.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnSelect.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnSelect.BorderRadius = 5;
            this.btnSelect.BorderSize = 0;
            this.btnSelect.FlatAppearance.BorderSize = 0;
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.ForeColor = System.Drawing.Color.White;
            this.btnSelect.Location = new System.Drawing.Point(423, 320);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(70, 30);
            this.btnSelect.TabIndex = 96;
            this.btnSelect.Text = "Select";
            this.btnSelect.TextColor = System.Drawing.Color.White;
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // SelectVehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(836, 362);
            this.Controls.Add(this.dgv_VehicleRecords);
            this.Controls.Add(this.lbl_VehiclePrice);
            this.Controls.Add(this.lbl_VehicleName);
            this.Controls.Add(this.las);
            this.Controls.Add(this.asd);
            this.Controls.Add(this.picbox_VehicleImage);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.panel1);
            this.Name = "SelectVehicle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectVehicle";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_VehicleImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_VehicleRecords)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_VehiclePrice;
        private System.Windows.Forms.Label lbl_VehicleName;
        private System.Windows.Forms.Label las;
        private System.Windows.Forms.Label asd;
        private System.Windows.Forms.PictureBox picbox_VehicleImage;
        private RoundedButton btnSelect;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.DataGridView dgv_VehicleRecords;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewPackageForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler ClientAdded;

        //For songs
        private int selectedPlaylistId;
        private string selectedPlaylistName;
        //casket
        public int SelectedCasketID { get; set; }
        private decimal casketPrice = 0.0M;
        //Vehicle
        public int SelectedVehicleID { get; set; }
        private decimal vehiclePrice = 0.0M;
        //Flower Arrangment
        public int SelectedFlowerID { get; set; }
        private string flowerName;
        private int flowerQuantity;
        private decimal flowerPrice = 0.0M;
        private string flowerAdditional;

        //Equipments
        public int equipmentID { get; set; }
        string equipmentName;
        int equipmentQuantity;

        // Embalming Prices
        private decimal baseEmbalmingPrice = 0.0M;
        private decimal additionalDayCharge = 0.0M;
        private int includedDays = 0;

        public AddNewPackageForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadEmbalmingPrices();
            InitializeDataGridView();
        }
        private void InitializeDataGridView()
        {
            // Check if columns are already added to prevent adding duplicates
            if (dgv_FlowerArrangement.Columns.Count == 0)
            {
                dgv_FlowerArrangement.Columns.Add("FlowerID", "Flower ID");
                dgv_FlowerArrangement.Columns.Add("FlowerName", "Flower");
                dgv_FlowerArrangement.Columns.Add("FlowerPrice", "Price");
                dgv_FlowerArrangement.Columns.Add("Quantity", "Quantity");
                dgv_FlowerArrangement.Columns.Add("Additional", "Additional");
            }
            if (dgv_Equipments.Columns.Count == 0)
            {
                dgv_Equipments.Columns.Add("EquipmentID", "Equipment ID");
                dgv_Equipments.Columns.Add("EquipmentName", "Equipment Name");
                dgv_Equipments.Columns.Add("EquipmentType", "Equipment Type");
                dgv_Equipments.Columns.Add("Quantity", "Quantity");
            }
        }
        private void LoadEmbalmingPrices()
        {
            string query = "SELECT IncludedDays, BasePrice, AdditionalDayCharge FROM EmbalmingPrice";

            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    includedDays = reader.GetInt32(0);
                    baseEmbalmingPrice = reader.GetDecimal(1);
                    additionalDayCharge = reader.GetDecimal(2);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading embalming prices: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;
                SelectedCasketID = selectCasketForm.SelectedCasketID;

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                SelectedVehicleID = selectVehicleForm.SelectedVehicleID;

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                var selectedFlowers = selectFlowerForm.SelectedFlowers;
                dgv_FlowerArrangement.Rows.Clear();

                foreach (var flower in selectedFlowers)
                {
                    dgv_FlowerArrangement.Rows.Add(flower.FlowerID, flower.FlowerName, flower.FlowerPrice.ToString("F2"), flower.Quantity, flower.Additional);

                    flowerPrice += flower.FlowerPrice * flower.Quantity;
                    SelectedFlowerID = flower.FlowerID;
                    flowerName = flower.FlowerName;
                    flowerQuantity = flower.Quantity;
                    flowerAdditional = flower.Additional;
                }

                UpdateEmbalmingPrice();
            }
        }
        private void btn_Song_Click(object sender, EventArgs e)
        {
            SelectSong selectPlaylistForm = new SelectSong();
            if (selectPlaylistForm.ShowDialog() == DialogResult.OK)
            {
                txt_Song.Text = selectPlaylistForm.SelectedPlaylistName;
                selectedPlaylistId = selectPlaylistForm.SelectedPlaylistId;
                selectedPlaylistName = selectPlaylistForm.SelectedPlaylistName;
            }
        }
        private void btn_SelectEquipment_Click(object sender, EventArgs e)
        {
            SelectEquipments selectEquipmentForm = new SelectEquipments();
            if (selectEquipmentForm.ShowDialog() == DialogResult.OK)
            {
                var selectedEquipments = selectEquipmentForm.SelectedEquipments;
                dgv_Equipments.Rows.Clear();

                foreach (var equipment in selectedEquipments)
                {
                    dgv_Equipments.Rows.Add(equipment.EquipmentID, equipment.EquipmentName, equipment.EquipmentType, equipment.Quantity);

                    // You can also add logic to update any totals or specific details for each equipment.
                    equipmentID = equipment.EquipmentID;
                    equipmentName = equipment.EquipmentName;
                    equipmentQuantity = equipment.Quantity;
                }
            }
        }
        private void btn_ClearCasket_Click(object sender, EventArgs e)
        {
            // Clear the casket text field
            txt_Casket.Text = string.Empty;

            // Reset the selected casket ID and price
            SelectedCasketID = 0;
            casketPrice = 0.0M;
            UpdateEmbalmingPrice();
        }
        private void btn_ClearVehicle_Click(object sender, EventArgs e)
        {
            // Clear the vehicle text field
            txt_Vehicle.Text = string.Empty;

            // Reset the selected vehicle ID and price
            SelectedVehicleID = 0;
            vehiclePrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearArrangement_Click(object sender, EventArgs e)
        {
            dgv_FlowerArrangement.Rows.Clear();

            SelectedFlowerID = 0;
            flowerPrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearPlaylist_Click(object sender, EventArgs e)
        {
            txt_Song.Text = string.Empty;

            selectedPlaylistId = 0;
        }
        private void btn_ClearEquipment_Click(object sender, EventArgs e)
        {
            dgv_Equipments.Rows.Clear();

            equipmentID = 0;
        }
        private void txt_EmbalmingDays_TextChanged(object sender, EventArgs e)
        {
            UpdateEmbalmingPrice();
        }
        private void UpdateEmbalmingPrice()
        {
            if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
            {
                // If the input is empty, set the embalming price to the base price
                txt_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice).ToString("F2");
                return; // Exit the method early
            }
            int embalmingDays = 0;
            if (int.TryParse(txt_EmbalmingDays.Text, out embalmingDays))
            {
                decimal embalmingPrice = 0;
                if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
                {
                    // Input is empty, so use the base embalming price
                    embalmingPrice = baseEmbalmingPrice;
                }
                if (embalmingDays > 0)
                {
                    // Start with the base embalming price
                    embalmingPrice = baseEmbalmingPrice;

                    if (embalmingDays > includedDays)
                    {
                        // Calculate additional charges if days exceed the included days
                        int additionalDays = embalmingDays - includedDays;
                        embalmingPrice += additionalDays * additionalDayCharge;
                    }
                }

                // Calculate the total price with or without embalming
                decimal totalPrice = casketPrice + vehiclePrice + flowerPrice + embalmingPrice;

                // Update the total price in the text box
                txt_PackagePrice.Text = totalPrice.ToString("F2");
            }
            else
            {
                txt_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice + baseEmbalmingPrice).ToString("F2");
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_PackageName.Text))
            {
                MessageBox.Show("Please enter a package name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                db.Open();

                // Insert into Package table
                string insertPackageQuery = @"INSERT INTO Package 
                               (CasketID, PlaylistsID, VehicleID, PackageName, 
                               CasketName, VehicleName, PlaylistsName, EmbalmingDays, TotalPrice) 
                               OUTPUT INSERTED.PackageID
                               VALUES 
                               (@CasketID, @PlaylistsID, @VehicleID, @PackageName, 
                               @CasketName, @VehicleName, @PlaylistsName, @EmbalmingDays, @TotalPrice)";
                SqlCommand packageCmd = new SqlCommand(insertPackageQuery, db);

                // Add parameters including PackageName
                packageCmd.Parameters.AddWithValue("@PackageName", txt_PackageName.Text.Trim());
                packageCmd.Parameters.AddWithValue("@CasketID", SelectedCasketID > 0 ? (object)SelectedCasketID : DBNull.Value);
                packageCmd.Parameters.AddWithValue("@PlaylistsID", selectedPlaylistId > 0 ? (object)selectedPlaylistId : DBNull.Value);
                packageCmd.Parameters.AddWithValue("@VehicleID", SelectedVehicleID > 0 ? (object)SelectedVehicleID : DBNull.Value);
                packageCmd.Parameters.AddWithValue("@CasketName", txt_Casket.Text.Trim());
                packageCmd.Parameters.AddWithValue("@VehicleName", txt_Vehicle.Text.Trim());
                packageCmd.Parameters.AddWithValue("@PlaylistsName", txt_Song.Text.Trim());
                packageCmd.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? (object)DBNull.Value : int.Parse(txt_EmbalmingDays.Text));
                packageCmd.Parameters.AddWithValue("@TotalPrice", decimal.Parse(txt_PackagePrice.Text));

                int packageID = (int)packageCmd.ExecuteScalar();

                // Insert into PackageFlowerArrangements table
                foreach (DataGridViewRow row in dgv_FlowerArrangement.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        string insertFlowerQuery = @"INSERT INTO PackageFlowerArrangements 
                                             (PackageID, ArrangementID, FlowerArrangementName, Quantity, Additional, PricePerUnit) 
                                             VALUES 
                                             (@PackageID, @ArrangementID, @FlowerArrangementName, @Quantity, @Additional, @PricePerUnit)";
                        SqlCommand flowerCmd = new SqlCommand(insertFlowerQuery, db);
                        flowerCmd.Parameters.AddWithValue("@PackageID", packageID);
                        flowerCmd.Parameters.AddWithValue("@ArrangementID", row.Cells["FlowerID"].Value);
                        flowerCmd.Parameters.AddWithValue("@FlowerArrangementName", row.Cells["FlowerName"].Value);
                        flowerCmd.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                        flowerCmd.Parameters.AddWithValue("@Additional", row.Cells["Additional"].Value ?? DBNull.Value);
                        flowerCmd.Parameters.AddWithValue("@PricePerUnit", row.Cells["FlowerPrice"].Value);
                        flowerCmd.ExecuteNonQuery();
                    }
                }

                // Insert into PackageEquipments table
                foreach (DataGridViewRow row in dgv_Equipments.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        string insertEquipmentQuery = @"INSERT INTO PackageEquipments 
                                                (PackageID, EquipmentID, EquipmentName, EquipmentType, Quantity) 
                                                VALUES 
                                                (@PackageID, @EquipmentID, @EquipmentName, @EquipmentType, @Quantity)";
                        SqlCommand equipmentCmd = new SqlCommand(insertEquipmentQuery, db);
                        equipmentCmd.Parameters.AddWithValue("@PackageID", packageID);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentID", row.Cells["EquipmentID"].Value);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentName", row.Cells["EquipmentName"].Value);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentType", row.Cells["EquipmentType"].Value);
                        equipmentCmd.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                        equipmentCmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Package and details added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClientAdded.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding package: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}

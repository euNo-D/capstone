﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class SelectVehicle : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public int SelectedVehicleID { get; set; }
        public string SelectedVehicleName { get; set; }
        public decimal SelectedVehiclePrice { get; set; }

        public SelectVehicle()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadVehicle();
        }

        private void LoadVehicle()
        {
            try
            {
                db.Open();
                string query = "SELECT VehicleID, VehicleName, VehicleTypeName, Price, VehicleImage FROM Vehicle " +
                               "JOIN VehicleType ON Vehicle.VehicleTypeID = VehicleType.VehicleTypeID";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataAdapter dt = new SqlDataAdapter(command);

                DataTable VehicleTable = new DataTable();
                dt.Fill(VehicleTable);
                dgv_VehicleRecords.DataSource = VehicleTable;

                dgv_VehicleRecords.Columns["VehicleID"].Visible = false;
                dgv_VehicleRecords.Columns["VehicleName"].HeaderText = "Vehicle";
                dgv_VehicleRecords.Columns["VehicleTypeName"].HeaderText = "Vehicle Type";
                dgv_VehicleRecords.Columns["Price"].HeaderText = "Price";
                dgv_VehicleRecords.Columns["VehicleImage"].HeaderText = "Image";
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading vehicles: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private void dgv_VehicleRecords_DoubleClick(object sender, EventArgs e)
        {
            if (dgv_VehicleRecords.SelectedRows.Count > 0)
            {
                // Get the selected casket's data
                DataRowView selectedRow = (DataRowView)dgv_VehicleRecords.SelectedRows[0].DataBoundItem;

                SelectedVehicleID = (int)selectedRow["VehicleID"];
                SelectedVehicleName = selectedRow["VehicleName"].ToString();
                SelectedVehiclePrice = (decimal)selectedRow["Price"];


                // Show the casket name in a label
                lbl_VehicleName.Text = SelectedVehicleName;
                lbl_VehiclePrice.Text = SelectedVehiclePrice.ToString("F2");

                if (selectedRow["VehicleImage"] != DBNull.Value)
                {
                    byte[] image = (byte[])selectedRow["VehicleImage"];
                    if (image.Length > 0)
                    {
                        using (MemoryStream ms = new MemoryStream(image))
                        {
                            picbox_VehicleImage.Image = Image.FromStream(ms);
                        }
                    }
                    else
                    {
                        picbox_VehicleImage.Image = null;
                    }
                }
                else
                {
                    picbox_VehicleImage.Image = null;
                }
            }
        }
        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (SelectedVehicleID > 0 && !string.IsNullOrEmpty(SelectedVehicleName))
            {
                this.DialogResult = DialogResult.OK;
                this.Close(); // Close the form
            }
            else
            {
                MessageBox.Show("Please select a casket.");
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadVehicle();
                return;
            }
            string query = @"SELECT VehicleID, VehicleName, VehicleTypeName, Price, VehicleImage 
                             FROM Vehicle 
                             JOIN VehicleType ON Vehicle.VehicleTypeID = VehicleType.VehicleTypeID 
                             WHERE VehicleName LIKE @SearchText OR VehicleTypeName LIKE @SearchText";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dgv_VehicleRecords.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_VehicleRecords.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewEmployee : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler ClientAdded;

        public AddNewEmployee()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            // Check if all fields are filled
            if (string.IsNullOrEmpty(txt_FirstName.Text) || string.IsNullOrEmpty(txt_LastName.Text) ||
                string.IsNullOrEmpty(txt_ContactNo.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }
            // Validate Contact No (must be exactly 11 characters)
            if (txt_ContactNo.Text.Length != 11)
            {
                MessageBox.Show("Contact No must be exactly 11 digits.");
                return;
            }

            try
            {
                // Get values from form controls
                string firstName = txt_FirstName.Text;
                string lastName = txt_LastName.Text;
                string contactNo = txt_ContactNo.Text;
                DateTime hireDate = dtp_HireDate.Value;

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO Employees (FirstName, LastName, Contact_No, HireDate) " +
                                     "VALUES (@FirstName, @LastName, @ContactNo, @HireDate)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    command.Parameters.AddWithValue("@ContactNo", contactNo);
                    command.Parameters.AddWithValue("@HireDate", hireDate);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Employee added successfully.");
                        ClientAdded.Invoke(this, EventArgs.Empty);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Error adding employee.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace ILAGAN_Management_System
{
    public partial class NewFlowerArrangement : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public NewFlowerArrangement()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadFlowerArrangementTypes();
            LoadFlowerArrangements();
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                picb_FlowerArrangement.Image = Image.FromFile(filePath);
            }
        }
        private void LoadFlowerArrangementTypes()
        {
            // Create a DataTable to hold the Flower Arrangement types
            string query = "SELECT ArrangementTypeID, ArrangementTypeName FROM FlowerArrangementsType";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                try
                {
                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dtFlowerArrangementTypes = new DataTable();
                        dtFlowerArrangementTypes.Load(reader);
                        cmb_FlowerArrangementType.DataSource = dtFlowerArrangementTypes;
                        cmb_FlowerArrangementType.DisplayMember = "ArrangementTypeName"; // The field to display
                        cmb_FlowerArrangementType.ValueMember = "ArrangementTypeID";
                        cmb_FlowerArrangementType.SelectedIndex = -1;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching Flower Arrangement Types: " + ex.Message);
                }
                finally
                {
                    db.Close(); // Ensure the database connection is closed
                }
            }
        }
        private void LoadFlowerArrangements()
        {
            try
            {
                string query = "SELECT ArrangementID, ArrangementName, ArrangementTypeName, Price, ArrangementImage, FlowerArrangements.ArrangementTypeID " +
                               "FROM FlowerArrangements " +
                               "JOIN FlowerArrangementsType ON FlowerArrangements.ArrangementTypeID = FlowerArrangementsType.ArrangementTypeID";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dtFlowerArrangements = new DataTable();
                adapter.Fill(dtFlowerArrangements);

                dgv_FlowerArrangmentList.DataSource = dtFlowerArrangements;
                dgv_FlowerArrangmentList.Columns["ArrangementTypeID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Flower Arrangements: " + ex.Message);
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            // Check if all fields are filled
            if (cmb_FlowerArrangementType.SelectedIndex == -1 || string.IsNullOrEmpty(txt_FlowerArrangementName.Text) || string.IsNullOrEmpty(txt_FlowerArrangementPrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                int flowerArrangementTypeId = (int)cmb_FlowerArrangementType.SelectedValue;
                string flowerArrangementName = txt_FlowerArrangementName.Text;
                decimal flowerArrangementPrice = decimal.Parse(txt_FlowerArrangementPrice.Text);

                // Convert image to byte array if an image is selected
                byte[] flowerArrangementImage = null;
                if (picb_FlowerArrangement.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        picb_FlowerArrangement.Image.Save(ms, picb_FlowerArrangement.Image.RawFormat);
                        flowerArrangementImage = ms.ToArray();
                    }
                }

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO FlowerArrangements (ArrangementTypeID, ArrangementImage, ArrangementName, Price) " +
                                     "VALUES (@ArrangementTypeID, @ArrangementImage, @ArrangementName, @Price)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@ArrangementTypeID", flowerArrangementTypeId);
                    command.Parameters.AddWithValue("@ArrangementImage", flowerArrangementImage ?? (object)DBNull.Value); // Use DBNull if no image is provided
                    command.Parameters.AddWithValue("@ArrangementName", flowerArrangementName);
                    command.Parameters.AddWithValue("@Price", flowerArrangementPrice);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Flower Arrangement inserted successfully.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Error inserting Flower Arrangement.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (dgv_FlowerArrangmentList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a Flower Arrangement to update.");
                return;
            }

            if (string.IsNullOrEmpty(txt_FlowerArrangementName.Text) || string.IsNullOrEmpty(txt_FlowerArrangementPrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                int arrangementId = Convert.ToInt32(dgv_FlowerArrangmentList.SelectedRows[0].Cells["ArrangementID"].Value);
                string arrangementName = txt_FlowerArrangementName.Text;
                decimal arrangementPrice = decimal.Parse(txt_FlowerArrangementPrice.Text);
                int arrangementTypeId = (int)cmb_FlowerArrangementType.SelectedValue;

                string updateQuery = "UPDATE FlowerArrangements SET ArrangementName = @ArrangementName, ArrangementTypeID = @ArrangementTypeID, " +
                                     "Price = @Price WHERE ArrangementID = @ArrangementID";

                using (SqlCommand command = new SqlCommand(updateQuery, db))
                {
                    command.Parameters.AddWithValue("@ArrangementName", arrangementName);
                    command.Parameters.AddWithValue("@ArrangementTypeID", arrangementTypeId);
                    command.Parameters.AddWithValue("@Price", arrangementPrice);
                    command.Parameters.AddWithValue("@ArrangementID", arrangementId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Flower Arrangement updated successfully.");
                        LoadFlowerArrangements();
                    }
                    else
                    {
                        MessageBox.Show("Error updating Flower Arrangement.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_FlowerArrangmentList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a Flower Arrangement to delete.");
                return;
            }

            try
            {
                int arrangementId = Convert.ToInt32(dgv_FlowerArrangmentList.SelectedRows[0].Cells["ArrangementID"].Value);

                string deleteQuery = "DELETE FROM FlowerArrangements WHERE ArrangementID = @ArrangementID";

                using (SqlCommand command = new SqlCommand(deleteQuery, db))
                {
                    command.Parameters.AddWithValue("@ArrangementID", arrangementId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Flower Arrangement deleted successfully.");
                        LoadFlowerArrangements();
                    }
                    else
                    {
                        MessageBox.Show("Error deleting Flower Arrangement.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dgv_FlowerArrangmentList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_FlowerArrangmentList.Rows[e.RowIndex];
                txt_FlowerArrangementName.Text = row.Cells["ArrangementName"].Value.ToString();
                txt_FlowerArrangementPrice.Text = row.Cells["Price"].Value.ToString();

                if (row.Cells["ArrangementTypeID"] != null && row.Cells["ArrangementTypeID"].Value != DBNull.Value)
                {
                    cmb_FlowerArrangementType.SelectedValue = Convert.ToInt32(row.Cells["ArrangementTypeID"].Value);
                }

                // Populate the PictureBox with the Flower Arrangement Image (if any)
                if (row.Cells["ArrangementImage"].Value != DBNull.Value)
                {
                    byte[] imageData = (byte[])row.Cells["ArrangementImage"].Value;
                    using (MemoryStream ms = new MemoryStream(imageData))
                    {
                        picb_FlowerArrangement.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    picb_FlowerArrangement.Image = null; // Set to null if no image is present
                }
            }
        }
    }
}

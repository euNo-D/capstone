﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using ILAGAN_Management_System;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class CreateNewServiceRequestForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        private int clientID;
        private string firstName;
        private string middleName;
        private string lastName;
        private string address;

        //for combo box document
        private List<DocumentType> documentTypes = new List<DocumentType>();
        //for combo box Cemetery
        private List<Cemetery> cemeteries = new List<Cemetery>();

        // resrvation id once inserted 
        private int reservationID;
        //value reservation
        private string chapelName;
        private decimal chapelPrice;

        //for Custpmize package
        private int customizepackageID;
        //value customize package 
        private int packageID;
        private int casketID;
        private int vehicleID;
        private int playlistsID;
        //Names
        private string packageName;
        private string casketName;
        private string vehicleName;
        private string playlistsName;
        private int embalmingDays;
        private decimal totalPrice;
        //service request
        private int serviceRequestID;

        public CreateNewServiceRequestForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadCemeteries();
            LoadDocumentTypes();
            LoadDiscounts();
            GetReservationDetails();
            lbl_SubTotal.Text = "₱ " + "0.00";
            defaultTime();
        }
        private void defaultTime()
        {
            dtp_burialtime.Format = DateTimePickerFormat.Time; 
            dtp_burialtime.ShowUpDown = true; 
            dtp_burialtime.Value = DateTime.Today.AddHours(7).AddMinutes(30); 
        }
        private void GetReservationDetails()
        {
            if (reservationID <= 0)
            {
                return; 
            }
            else
            {
                // Query to get package details
                string query = @"SELECT cr.Location, cr.ChapelID, ch.ChapelName 
                                 FROM ChapelReservation cr
                                 LEFT JOIN Chapel ch ON cr.ChapelID = ch.ChapelID
                                 WHERE cr.ReservationID = @ReservationID";

                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@ReservationID", reservationID);

                    try
                    {
                        db.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            if (reader.Read())
                            {

                                // Retrieve values
                                chapelName = reader["ChapelName"] != DBNull.Value ? reader["ChapelName"].ToString() : "N/A";
                            }
                            else
                            {
                                MessageBox.Show("No package details found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching package details: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }
        private void btn_Reservation_Click(object sender, EventArgs e)
        {
            if (clientID == 0)
            {
                MessageBox.Show("Please select client first.", "Client Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            OpenChapelSelectionForm();
        }
        private void OpenChapelSelectionForm()
        {
            string clientName = ConstructClientName();

            if (string.IsNullOrEmpty(clientName))
            {
                MessageBox.Show("First name and last name cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (clientID <= 0)
            {
                MessageBox.Show("Invalid client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Chapel_Service chapelServiceForm = new Chapel_Service(clientID, clientName, reservationID)
            {
            };
            chapelServiceForm.ShowDialog();

            if (chapelServiceForm.DialogResult == DialogResult.OK)
            {
                reservationID = chapelServiceForm.ReservationID;
                chapelPrice = chapelServiceForm.pricechap;
                DisplayPrices();
                DateTime endDate = GetReservationEndDate();
                dtp_burialdate.Value = endDate;
                MessageBox.Show("Chapel reservation saved successfully. Reservation ID: " + reservationID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        
        // if client dont have a middle name
        private string ConstructClientName()
        {
            string firstName = lbl_FirstName.Text.Trim();
            string lastName = lbl_LastName.Text.Trim();
            string middleName = lbl_MiddleName.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
                return null;

            if (string.IsNullOrEmpty(middleName))
                return firstName + " " + lastName;

            return firstName + " " + middleName + " " + lastName;
        }
        private void btn_Browse_Click(object sender, EventArgs e)
        {
            btn_NewClient browseForm = new btn_NewClient();
            if (browseForm.ShowDialog() == DialogResult.OK)
            {
                clientID = browseForm.SelectedClientID;
                firstName = browseForm.SelectedFirstName;
                middleName = browseForm.SelectedMiddleName;
                lastName = browseForm.SelectedLastName;
                address = browseForm.SelectedAddress;

                //Display
                lbl_FirstName.Text = firstName;
                lbl_MiddleName.Text = middleName;
                lbl_LastName.Text = lastName;
                lbl_Address.Text = address;
            }
        }
        private void AddNewClientForm_ClientAdded(object sender, EventArgs e)
        {
            MessageBox.Show("A new client was added.");
        }
        private int SearchClients()
        {
            string firstName = lbl_FirstName.Text.Trim();
            string middleName = lbl_MiddleName.Text.Trim();
            string lastName = lbl_LastName.Text.Trim();
            string address = lbl_Address.Text;

            string query = @"SELECT ClientID, FirstName, MiddleName, LastName, Address, Contact_No FROM Clients
                     WHERE FirstName = @FirstName 
                     AND MiddleName = @MiddleName 
                     AND LastName = @LastName
                     AND Address = @Address";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@MiddleName", middleName);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@Address", address);

                try
                {
                    db.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable clientTable = new DataTable();
                    adapter.Fill(clientTable);

                    if (clientTable.Rows.Count == 1)
                    {
                        // Single client found
                        return Convert.ToInt32(clientTable.Rows[0]["ClientID"]);
                    }
                }
                finally
                {
                    db.Close();
                }
            }
            return 0;
        }
        //for combobox ducument
        private void LoadDocumentTypes()
        {
            cmb_DocumentType.Items.Clear();
            string query = "SELECT DocumentTypeID, DocumentTypeName FROM DocumentType"; // Include ID in the query
            using (SqlCommand doc_command = new SqlCommand(query, db))
            {
                db.Open();
                using (SqlDataReader doc_reader = doc_command.ExecuteReader())
                {
                    while (doc_reader.Read())
                    {
                        var docType = new DocumentType
                        {
                            ID = (int)doc_reader["DocumentTypeID"],
                            Name = doc_reader["DocumentTypeName"].ToString()
                        };
                        documentTypes.Add(docType);
                        cmb_DocumentType.Items.Add(docType); // Add to ComboBox
                    }
                }
                db.Close();
            }
        }
        //uploading pic for document
        private void btn_Upload_Click(object sender, EventArgs e)
        {
            if (cmb_DocumentType.SelectedItem == null)
            {
                MessageBox.Show("Please select a document type before uploading an image.", "Document Type Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                picb_documents.Image = Image.FromFile(filePath);
            }
        }
        //view the document
        private void btn_View_Click(object sender, EventArgs e)
        {
            if (picb_documents.Image != null)
            {
                ImageViewerForm viewer = new ImageViewerForm(picb_documents.Image);
                viewer.ShowDialog();
            }
            else
            {
                MessageBox.Show("No document image available to view.", "Image Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //for combo box cemetery
        private void LoadCemeteries()
        {
            cmb_CemeteryLocation.Items.Clear();
            string queryc = "SELECT CemeteryID, CemeteryName FROM Cemeteries";
            using (SqlCommand command = new SqlCommand(queryc, db))
            {
                try
                {
                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var cemetery = new Cemetery
                            {
                                ID = (int)reader["CemeteryID"],
                                Name = reader["CemeteryName"].ToString()
                            };
                            cemeteries.Add(cemetery);
                            cmb_CemeteryLocation.Items.Add(cemetery);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading cemeteries: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }
        }
        private void btn_CustomizePackage_Click_1(object sender, EventArgs e)
        {
            CustomizePackage customizePackageForm = new CustomizePackage(customizepackageID);

            if (customizePackageForm.ShowDialog() == DialogResult.OK)
            {
                customizepackageID = customizePackageForm.CustomizePackageID;
                DisplayPackageDetails();
                DisplayPrices();
                MessageBox.Show("Customize Package saved successfully. Customize Package ID: " + customizepackageID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void DisplayPackageDetails()
        {
            if (customizepackageID <= 0)
            {
                return; // Exit if there is no valid customize package ID
            }
            else
            {
                // Query to get package details
                string query = @"SELECT PackageID, PackageName, CasketID, CasketName, VehicleID, VehicleName,  
                                        PlaylistSongsID, PlaylistsName, EmbalmingDays, TotalPrice 
                                 FROM CustomizePackage 
                                 WHERE CustomizePackageID = @CustomizePackageID";

                // Query to get flower arrangements
                string flowerQuery = @"SELECT CustomizePackageFlowerArrangementID, ArrangementID, FlowerArrangementName, Quantity, Additional, PricePerUnit 
                               FROM CustomizePackageFlowerArrangements 
                               WHERE CustomizePackageID = @CustomizePackageID";

                string equipmentQuery = @"SELECT CustomizePackageEquipmentID, EquipmentID, EquipmentName, EquipmentType, Quantity 
                                  FROM CustomizePackageEquipments 
                                  WHERE CustomizePackageID = @CustomizePackageID";

                try
                {
                    db.Open();

                    // Fetch and display package details
                    using (SqlCommand command = new SqlCommand(query, db))
                    {
                        command.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Clear existing columns and rows
                            dgv_PackageDetails.Columns.Clear();
                            dgv_PackageDetails.Rows.Clear();

                            // Add columns for Name and Value
                            dgv_PackageDetails.Columns.Add("Name", "Name");
                            dgv_PackageDetails.Columns.Add("Value", "Value");

                            if (reader.Read())
                            {
                                // Get value IDs
                                packageID = reader["PackageID"] != DBNull.Value ? Convert.ToInt32(reader["PackageID"]) : 0;
                                casketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                                vehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;
                                playlistsID = reader["PlaylistSongsID"] != DBNull.Value ? Convert.ToInt32(reader["PlaylistSongsID"]) : 0;

                                // Retrieve values
                                packageName = reader["PackageName"] != DBNull.Value ? reader["PackageName"].ToString() : "N/A";
                                casketName = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                                vehicleName = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                                playlistsName = reader["PlaylistsName"] != DBNull.Value ? reader["PlaylistsName"].ToString() : "N/A";
                                embalmingDays = reader["EmbalmingDays"] != DBNull.Value ? Convert.ToInt32(reader["EmbalmingDays"]) : 0;
                                totalPrice = (decimal)reader["TotalPrice"];

                                // Add rows for each detail
                                dgv_PackageDetails.Rows.Add("Package", packageName);
                                dgv_PackageDetails.Rows.Add("Casket", casketName);
                                dgv_PackageDetails.Rows.Add("Vehicle", vehicleName);
                                dgv_PackageDetails.Rows.Add("Playlists", playlistsName);
                                dgv_PackageDetails.Rows.Add("Embalming Days", embalmingDays);
                                dgv_PackageDetails.Rows.Add("Total Price", totalPrice.ToString("F2"));
                            }
                            else
                            {
                                MessageBox.Show("No package details found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }

                    // Fetch and display flower arrangements
                    List<FlowerArrangement> flowerArrangements = new List<FlowerArrangement>();
                    using (SqlCommand flowerCommand = new SqlCommand(flowerQuery, db))
                    {
                        flowerCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                        using (SqlDataReader flowerReader = flowerCommand.ExecuteReader())
                        {
                            if (flowerReader.HasRows)
                            {
                                dgv_PackageDetails.Rows.Add("Flower Arrangements", ""); // Header row for flowers

                                while (flowerReader.Read())
                                {
                                    FlowerArrangement flower = new FlowerArrangement
                                    {
                                        ArrangementID = flowerReader["ArrangementID"] != DBNull.Value ? Convert.ToInt32(flowerReader["ArrangementID"]) : 0,
                                        FlowerArrangementName = flowerReader["FlowerArrangementName"] != DBNull.Value ? flowerReader["FlowerArrangementName"].ToString() : "N/A",
                                        Quantity = flowerReader["Quantity"] != DBNull.Value ? Convert.ToInt32(flowerReader["Quantity"]) : 0,
                                        Additional = flowerReader["Additional"] != DBNull.Value ? flowerReader["Additional"].ToString() : "",
                                        PricePerUnit = flowerReader["PricePerUnit"] != DBNull.Value ? Convert.ToDecimal(flowerReader["PricePerUnit"]) : 0
                                    };

                                    flowerArrangements.Add(flower);

                                    string flowerDetails = flower.FlowerArrangementName + ", Qty: " + flower.Quantity + ", Price: " + flower.PricePerUnit + ", Notes: " + flower.Additional;
                                    dgv_PackageDetails.Rows.Add(" - Flower", flowerDetails);
                                }
                            }
                        }
                    }
                    // Fetch and display equipment details
                    List<Equipment> equipmentList = new List<Equipment>();
                    using (SqlCommand equipmentCommand = new SqlCommand(equipmentQuery, db))
                    {
                        equipmentCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                        using (SqlDataReader equipmentReader = equipmentCommand.ExecuteReader())
                        {
                            if (equipmentReader.HasRows)
                            {
                                dgv_PackageDetails.Rows.Add("Equipment", ""); // Header row for equipment

                                while (equipmentReader.Read())
                                {
                                    Equipment equipment = new Equipment
                                    {
                                        EquipmentID = equipmentReader["EquipmentID"] != DBNull.Value ? Convert.ToInt32(equipmentReader["EquipmentID"]) : 0,
                                        EquipmentName = equipmentReader["EquipmentName"] != DBNull.Value ? equipmentReader["EquipmentName"].ToString() : "N/A",
                                        EquipmentType = equipmentReader["EquipmentType"] != DBNull.Value ? equipmentReader["EquipmentType"].ToString() : "N/A",
                                        Quantity = equipmentReader["Quantity"] != DBNull.Value ? Convert.ToInt32(equipmentReader["Quantity"]) : 0
                                    };

                                    equipmentList.Add(equipment);

                                    string equipmentDetails = equipment.EquipmentName + " (" + equipment.EquipmentType + "), Qty: " + equipment.Quantity;
                                    dgv_PackageDetails.Rows.Add(" - Equipment", equipmentDetails);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching package details: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }
        }

        //display the price 
        private void DisplayPrices()
        {
            string chapelName = "";

            if (reservationID > 0)
            {
                // Check if reservationID has a valid value
                string chapelQuery = @"SELECT c.Price, c.ChapelName 
                                       FROM Chapel c 
                                       JOIN ChapelReservation cr ON c.ChapelID = cr.ChapelID
                                       WHERE cr.ReservationID = @ReservationID";
                using (SqlCommand chapelCommand = new SqlCommand(chapelQuery, db))
                {
                    chapelCommand.Parameters.AddWithValue("@ReservationID", reservationID);

                    try
                    {
                        db.Open();
                        using (SqlDataReader reader = chapelCommand.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                chapelName = reader["ChapelName"] != DBNull.Value ? reader["ChapelName"].ToString() : "Unknown Chapel";
                            }
                            else
                            {
                                lbl_SubTotal.Text = "0.00";
                                return;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching chapel price: " + ex.Message);
                        return; // Exit on error
                    }
                    finally
                    {
                        db.Close();
                    }

                }
            }
            decimal packageTotalPrice = 0;

            if (customizepackageID > 0)
            {
                string packageQuery = "SELECT TotalPrice FROM CustomizePackage WHERE CustomizePackageID = @CustomizePackageID";

                using (SqlCommand packageCommand = new SqlCommand(packageQuery, db))
                {
                    packageCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);

                    try
                    {
                        db.Open();
                        object packageResult = packageCommand.ExecuteScalar();

                        if (packageResult != null)
                        {
                            packageTotalPrice = Convert.ToDecimal(packageResult);
                        }
                        else
                        {
                            lbl_SubTotal.Text = "Customize package price not available"; 
                            return; 
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching customize package price: " + ex.Message);
                        return; // Exit on error
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }

            decimal totalPrice = chapelPrice + packageTotalPrice;
            lbl_SubTotal.Text = "₱ " + totalPrice.ToString("F2");

            lbl_TotalPrice.Text = "₱ " + totalPrice.ToString("F2");

            //display the service location
            if (reservationID > 0)
            {
                txt_ServiceLocation.Text = chapelName;
            }
        }
        private DateTime GetReservationEndDate()
        {
            DateTime endDate = DateTime.Today; // Default in case of error

            string query = "SELECT EndDate FROM ChapelReservation WHERE ReservationID = @ReservationID";

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                cmd.Parameters.AddWithValue("@ReservationID", reservationID);

                try
                {
                    db.Open();
                    var result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        endDate = Convert.ToDateTime(result);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving reservation end date: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    db.Close();
                }
            }

            return endDate;
        }
        //for the discount 
        private void LoadDiscounts()
        {
            cmb_Discount.Items.Clear();
            string query = "SELECT DiscountID, DiscountName, DiscountRate FROM Discounts";
            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable discountTable = new DataTable();
                adapter.Fill(discountTable);

                cmb_Discount.DataSource = discountTable;
                cmb_Discount.DisplayMember = "DiscountName";
                cmb_Discount.ValueMember = "DiscountID"; // Use DiscountID as ValueMember

                cmb_Discount.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading discounts: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void cmb_Discount_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Discount.SelectedItem != null)
            {
                DataRowView selectedRow = (DataRowView)cmb_Discount.SelectedItem;
                decimal discountRate = (decimal)selectedRow["DiscountRate"];

                if (string.IsNullOrEmpty(lbl_DiscountedPrice.Text) || lbl_DiscountedPrice.Text == "0")
                {
                    MessageBox.Show("Please ensure that a chapel reservation has been made and the price is available.", "Price Not Available", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                CalculateTotalPrice(discountRate);
            }
        }
        // calculate the totalprice and discount
        private void CalculateTotalPrice(decimal discountRate)
        {
            decimal totalPrice = 0;

            // Check if ReservationID is not null and fetch the chapel price
            if (reservationID > 0)
            {
                totalPrice = chapelPrice;
            }
            // Fetch the total price from the CustomizePackage if it is set
            if (customizepackageID > 0)
            {
                string packageQuery = "SELECT TotalPrice FROM CustomizePackage WHERE CustomizePackageID = @CustomizePackageID";
                using (SqlCommand packageCommand = new SqlCommand(packageQuery, db))
                {
                    packageCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                    try
                    {
                        db.Open();
                        object packageResult = packageCommand.ExecuteScalar();
                        if (packageResult != null)
                        {
                            totalPrice += Convert.ToDecimal(packageResult);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching package price: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
            // Calculate discount amount
            decimal discountAmount = totalPrice * (discountRate / 100);
            decimal finalPrice = totalPrice - discountAmount;

            // Update the label to display the final price
            lbl_DiscountedPrice.Text = "₱ " + finalPrice.ToString("F2");
            //total price
            lbl_TotalPrice.Text =  "₱ " + finalPrice.ToString("F2");
        }
        private bool ValidateBurialDate()
        {
            // Retrieve the EndDate from the database based on ReservationID
            DateTime endDate;

            string query = "SELECT EndDate FROM ChapelReservation WHERE ReservationID = @ReservationID";

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                cmd.Parameters.AddWithValue("@ReservationID", reservationID);

                try
                {
                    db.Open();
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        endDate = Convert.ToDateTime(result);

                        // Check if dtp_burialdate.Value is equal to endDate
                        if (dtp_burialdate.Value.Date != endDate.Date)
                        {
                            MessageBox.Show("Burial date must be the same as the reservation's end date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false; ;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No reservation found with the given ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false; 
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving reservation date: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false; 
                }
                finally
                {
                    db.Close();
                }
            }
            return true;
        }
        // btn Add 
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_DFname.Text) || string.IsNullOrEmpty(txt_DLname.Text))
            {
                MessageBox.Show("Please enter the deceased's first name and last name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (reservationID > 0)
            {
                if (!ValidateBurialDate())
                {
                    return;
                }
            }
            if (clientID == 0)
            {
                MessageBox.Show("Please select client first.", "Client Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Do you want to create this service request?",
                                          "Confirm Creation",
                                          MessageBoxButtons.YesNo,
                                          MessageBoxIcon.Question);

            // If the user clicks Yes, proceed to add the service request
            if (result == DialogResult.Yes)
            {
                AddServiceRequest();
                if (serviceRequestID > 0)
                {
                    InsertFlowerArrangements();
                    InsertEquipment();
                }
                DeleteCustomizePackages();
                ServiceRequestPrint printForm = new ServiceRequestPrint(serviceRequestID);
                printForm.ShowDialog();
            }

        }
        private decimal GetRealPrice(string labelText)
        {
            // Remove "₱" symbol and parse the remaining text to decimal
            string priceText = labelText.Replace("₱", "").Trim();
            decimal price = 0;

            if (decimal.TryParse(priceText, out price))
            {
                return price;
            }
            else
            {
                return 0; // Return 0 if parsing fails
            }
        }
        // to add service request databse 
        private void AddServiceRequest()
        {
            int currentUserId = CurrentUser.UserID;
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            /*int clientID = SearchClients();
            if (clientID <= 0)
            {
                MessageBox.Show("Invalid client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }*/
            string clientName = ConstructClientName();
            // Document combo box - optional
            int? selectedDocumentTypeID = null;
            string selectedDocumentTypeName = null;

            if (cmb_DocumentType.SelectedItem != null)
            {
                var selectedDocumentType = (DocumentType)cmb_DocumentType.SelectedItem;
                selectedDocumentTypeID = selectedDocumentType.ID;
                selectedDocumentTypeName = selectedDocumentType.Name;
            }

            //cemetery cobobox - optional
            int? selectedCemeteryID = null;
            string selectedCemeteryName = null;

            if (cmb_CemeteryLocation.SelectedItem != null)
            {
                var selectedCemetery = (Cemetery)cmb_CemeteryLocation.SelectedItem;
                selectedCemeteryID = selectedCemetery.ID;
                selectedCemeteryName = selectedCemetery.Name;
            }

            // Get the selected discount
            int? discountID = cmb_Discount.SelectedValue != null ? (int?)cmb_Discount.SelectedValue : null;
            string discountName = cmb_Discount.SelectedItem != null ? ((DataRowView)cmb_Discount.SelectedItem)["DiscountName"].ToString() : string.Empty;
            decimal discountRate = cmb_Discount.SelectedItem != null ? (decimal)((DataRowView)cmb_Discount.SelectedItem)["DiscountRate"] : 0;

            string query = @"INSERT INTO ServiceRequests (UserID, ClientID, ServiceStatusID, DocumentTypeID, CemeteryID,
                                                        ReservationID, DiscountID, CopPackageID, CopCasketID, CopVehicleID, 
                                                        CopPlaylistID, ClientName, DeceasedFName, DeceasedLName, 
                                                        DeceasedMName, PackageName, CasketName, VehicleName,
                                                        PlaylistName, ServiceLocation, CemeteryLocation, DateBurial, 
                                                        TimeBurial, Address, DocumentType, DocumentImage, EmbalmingDays, SubTotal, 
                                                        Discount, DiscountRate, DiscountTotal, TotalPrice,  CreationDate, CreatedBy) 
                                                        OUTPUT INSERTED.ServiceRequestID
                                                        VALUES 
                                                        (@UserID, @ClientID, @ServiceStatusID, @DocumentTypeID, @CemeteryID, 
                                                        @ReservationID, @DiscountID, @CopPackageID, @CopCasketID, @CopVehicleID,
                                                        @CopPlaylistID, @ClientName, @DeceasedFName, @DeceasedLName, 
                                                        @DeceasedMName, @PackageName, @CasketName, @VehicleName, 
                                                        @PlaylistName,@ServiceLocation, @CemeteryLocation, @DateBurial, 
                                                        @TimeBurial, @Address, @DocumentType, @DocumentImage, @EmbalmingDays, @SubTotal,
                                                        @Discount, @DiscountRate, @DiscountTotal, @TotalPrice, GETDATE(), @CreatedBy);";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@UserID", currentUserId);
                command.Parameters.AddWithValue("@ClientID", clientID);
                command.Parameters.AddWithValue("@ServiceStatusID", 1);
                command.Parameters.AddWithValue("@CemeteryID", (object)selectedCemeteryID ?? DBNull.Value);
                command.Parameters.AddWithValue("@DocumentTypeID", (object)selectedDocumentTypeID ?? DBNull.Value);
                command.Parameters.AddWithValue("@ReservationID", reservationID > 0 ? (object)reservationID : DBNull.Value);
                command.Parameters.AddWithValue("@DiscountID", (object)discountID ?? DBNull.Value);
                
                // Packages
                command.Parameters.AddWithValue("@CopPackageID", packageID > 0 ? (object)packageID : DBNull.Value);
                command.Parameters.AddWithValue("@CopCasketID", casketID > 0 ? (object)casketID : DBNull.Value);
                command.Parameters.AddWithValue("@CopVehicleID", vehicleID > 0 ? (object)vehicleID : DBNull.Value);
                command.Parameters.AddWithValue("@CopPlaylistID", playlistsID > 0 ? (object)playlistsID : DBNull.Value);

                // Client and deceased information
                command.Parameters.AddWithValue("@ClientName", clientName);
                command.Parameters.AddWithValue("@DeceasedFName", txt_DFname.Text);
                command.Parameters.AddWithValue("@DeceasedLName", txt_DLname.Text);
                command.Parameters.AddWithValue("@DeceasedMName", string.IsNullOrEmpty(txt_DMname.Text) ? (object)DBNull.Value : txt_DMname.Text);

                // Package information
                command.Parameters.AddWithValue("@PackageName", string.IsNullOrEmpty(packageName) ? DBNull.Value : (object)packageName);
                command.Parameters.AddWithValue("@CasketName", string.IsNullOrEmpty(casketName) ? DBNull.Value : (object)casketName); 
                command.Parameters.AddWithValue("@VehicleName", string.IsNullOrEmpty(vehicleName) ? DBNull.Value : (object)vehicleName);
                command.Parameters.AddWithValue("@PlaylistName", string.IsNullOrEmpty(playlistsName) ? DBNull.Value : (object)playlistsName);

                // Burial and service details
                command.Parameters.AddWithValue("@ServiceLocation", string.IsNullOrEmpty(txt_ServiceLocation.Text) ? (object)DBNull.Value : txt_ServiceLocation.Text);
                command.Parameters.AddWithValue("@CemeteryLocation", selectedCemeteryName ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@DateBurial", dtp_burialdate.Value != DateTime.MinValue ? (object)dtp_burialdate.Value : DBNull.Value);
                command.Parameters.AddWithValue("@TimeBurial", dtp_burialtime.Value != DateTime.MinValue ? (object)dtp_burialtime.Value.TimeOfDay : DBNull.Value);
                command.Parameters.AddWithValue("@Address", lbl_Address.Text);

                // Document details
                command.Parameters.AddWithValue("@DocumentType", selectedDocumentTypeName ?? (object)DBNull.Value);
                if (picb_documents.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        picb_documents.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        command.Parameters.AddWithValue("@DocumentImage", ms.ToArray());
                    }
                }
                else
                {
                    command.Parameters.Add("@DocumentImage", SqlDbType.VarBinary).Value = DBNull.Value;
                }
                
                // Service specifics
                command.Parameters.AddWithValue("@EmbalmingDays", embalmingDays > 0 ? (object)embalmingDays : DBNull.Value);
                command.Parameters.AddWithValue("@SubTotal", GetRealPrice(lbl_SubTotal.Text));

                // Discount handling
                command.Parameters.AddWithValue("@Discount", discountName);
                command.Parameters.AddWithValue("@DiscountRate", discountRate);
                command.Parameters.AddWithValue("@DiscountTotal", string.IsNullOrEmpty(lbl_DiscountedPrice.Text) ? (object)DBNull.Value : GetRealPrice(lbl_DiscountedPrice.Text));
                command.Parameters.AddWithValue("@TotalPrice", GetRealPrice(lbl_TotalPrice.Text));

                command.Parameters.AddWithValue("@CreatedBy", createdBy);

                try
                {
                    db.Open();
                    serviceRequestID = Convert.ToInt32(command.ExecuteScalar());
                    MessageBox.Show("Service Request added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding service request: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        private void InsertFlowerArrangements()
        {
            string selectQuery = @"SELECT ArrangementID, FlowerArrangementName, Quantity, Additional, PricePerUnit
                           FROM CustomizePackageFlowerArrangements
                           WHERE CustomizePackageID = @CustomizePackageID";

            string flowerInsertQuery = @"INSERT INTO ServiceRequestsFlowerArrangements 
                                 (ServiceRequestID, ArrangementID, FlowerArrangementName, Quantity, Additional, PricePerUnit)
                                 VALUES 
                                 (@ServiceRequestID, @ArrangementID, @FlowerArrangementName, @Quantity, @Additional, @PricePerUnit);";

            try
            {
                if (serviceRequestID == 0)
                {
                    MessageBox.Show("Invalid ServiceRequestID. Please check the ServiceRequest creation step.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                db.Open();

                // Get the list of selected flower arrangements
                using (SqlCommand selectCmd = new SqlCommand(selectQuery, db))
                {
                    selectCmd.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);

                    using (SqlDataReader reader = selectCmd.ExecuteReader())
                    {
                        // First, read all rows into a list (or process them in a loop)
                        var flowerArrangements = new List<FlowerArrangement>();

                        while (reader.Read())
                        {
                            flowerArrangements.Add(new FlowerArrangement
                            {
                                ArrangementID = (int)reader["ArrangementID"],
                                FlowerArrangementName = reader["FlowerArrangementName"].ToString(),
                                Quantity = (int)reader["Quantity"],
                                Additional = reader["Additional"] != DBNull.Value ? reader["Additional"].ToString() : null,
                                PricePerUnit = (decimal)reader["PricePerUnit"]
                            });
                        }

                        // After closing the reader, insert the flower arrangements
                        reader.Close();

                        foreach (var flower in flowerArrangements)
                        {
                            using (SqlCommand insertCmd = new SqlCommand(flowerInsertQuery, db))
                            {
                                insertCmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                                insertCmd.Parameters.AddWithValue("@ArrangementID", flower.ArrangementID);
                                insertCmd.Parameters.AddWithValue("@FlowerArrangementName", flower.FlowerArrangementName);
                                insertCmd.Parameters.AddWithValue("@Quantity", flower.Quantity);
                                insertCmd.Parameters.AddWithValue("@Additional", string.IsNullOrEmpty(flower.Additional) ? (object)DBNull.Value : flower.Additional);
                                insertCmd.Parameters.AddWithValue("@PricePerUnit", flower.PricePerUnit);

                                insertCmd.ExecuteNonQuery();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting flower arrangements: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                db.Close();
            }
        }
        private void InsertEquipment()
        {
            string selectQuery = @"SELECT EquipmentID, EquipmentName, EquipmentType, Quantity
                           FROM CustomizePackageEquipments
                           WHERE CustomizePackageID = @CustomizePackageID";

            string equipmentInsertQuery = @"INSERT INTO ServiceRequestsPackageEquipments 
                                    (ServiceRequestID, EquipmentID, EquipmentName, EquipmentType, Quantity)
                                    VALUES 
                                    (@ServiceRequestID, @EquipmentID, @EquipmentName, @EquipmentType, @Quantity);";

            try
            {
                if (serviceRequestID == 0)
                {
                    MessageBox.Show("Invalid ServiceRequestID. Please check the ServiceRequest creation step.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                db.Open();

                using (SqlCommand selectCmd = new SqlCommand(selectQuery, db))
                {
                    selectCmd.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);

                    using (SqlDataReader reader = selectCmd.ExecuteReader())
                    {
                        var equipmentList = new List<Equipment>();

                        while (reader.Read())
                        {
                            equipmentList.Add(new Equipment
                            {
                                EquipmentID = (int)reader["EquipmentID"],
                                EquipmentName = reader["EquipmentName"].ToString(),
                                EquipmentType = reader["EquipmentType"].ToString(),
                                Quantity = (int)reader["Quantity"]
                            });
                        }

                        // After closing the reader, insert the equipment
                        reader.Close();

                        foreach (var equipment in equipmentList)
                        {
                            using (SqlCommand insertCmd = new SqlCommand(equipmentInsertQuery, db))
                            {
                                insertCmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                                insertCmd.Parameters.AddWithValue("@EquipmentID", equipment.EquipmentID);
                                insertCmd.Parameters.AddWithValue("@EquipmentName", equipment.EquipmentName);
                                insertCmd.Parameters.AddWithValue("@EquipmentType", equipment.EquipmentType);
                                insertCmd.Parameters.AddWithValue("@Quantity", equipment.Quantity);

                                insertCmd.ExecuteNonQuery();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting equipment: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                db.Close();
            }
        }

        private void DeleteCustomizePackages()
        {
            // Delete flower arrangements first
            string deleteFlowersQuery = "DELETE FROM CustomizePackageFlowerArrangements";
            using (SqlCommand deleteFlowersCommand = new SqlCommand(deleteFlowersQuery, db))
            {
                db.Open();
                deleteFlowersCommand.ExecuteNonQuery();
                db.Close();
            }
            string deleteEquipmentQuery = "DELETE FROM CustomizePackageEquipments";
            using (SqlCommand deleteEquipmentCommand = new SqlCommand(deleteEquipmentQuery, db))
            {
                db.Open();
                deleteEquipmentCommand.ExecuteNonQuery();
                db.Close();
            }

            string deleteQuery = "DELETE FROM CustomizePackage";
            using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, db))
            {
                db.Open();
                deleteCommand.ExecuteNonQuery();
                db.Close();
            }
        }


        private void CreateNewServiceRequestForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (reservationID > 0 || customizepackageID > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to exit? Unsaved data will be deleted.",
                                          "Confirm Exit",
                                          MessageBoxButtons.YesNo,
                                          MessageBoxIcon.Warning);
                if (result == DialogResult.No)
                {
                    // Prevent the form from closing
                    e.Cancel = true;
                    return;
                }
                if (reservationID > 0)
                {
                    DeleteReservation();
                }

                if (customizepackageID > 0)
                {
                    DeleteCustomizePackage();
                }
            }
        }
        private void DeleteReservation()
        {
            string checkIfLinkedToServiceRequestQuery = "SELECT COUNT(*) FROM ServiceRequests WHERE ReservationID = @ReservationID";
            int linkedServiceRequestCount;

            try
            {
                db.Open();
                using (SqlCommand checkServiceRequestCommand = new SqlCommand(checkIfLinkedToServiceRequestQuery, db))
                {
                    checkServiceRequestCommand.Parameters.AddWithValue("@ReservationID", reservationID);
                    linkedServiceRequestCount = (int)checkServiceRequestCommand.ExecuteScalar(); // Returns number of linked service requests
                }

                // If linked to a service request, don't delete
                if (linkedServiceRequestCount > 0)
                {
                    return;
                }

                string deleteReservationQuery = "DELETE FROM ChapelReservation WHERE ReservationID = @ReservationID";
                using (SqlCommand deleteReservationCommand = new SqlCommand(deleteReservationQuery, db))
                {
                    deleteReservationCommand.Parameters.AddWithValue("@ReservationID", reservationID);
                    deleteReservationCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting reservation: " + ex.Message, "Deletion Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void DeleteCustomizePackage()
        {
            string deleteFlowerArrangementsQuery = "DELETE FROM CustomizePackageFlowerArrangements WHERE CustomizePackageID = @CustomizePackageID";
            string deleteEquipmentsQuery = "DELETE FROM CustomizePackageEquipments WHERE CustomizePackageID = @CustomizePackageID";
            string deleteCustomizePackageQuery = "DELETE FROM CustomizePackage WHERE CustomizePackageID = @CustomizePackageID";

            try
            {
                db.Open();

                // First, delete the related flower arrangements and equipment entries
                using (SqlCommand deleteFlowerArrangementsCommand = new SqlCommand(deleteFlowerArrangementsQuery, db))
                {
                    deleteFlowerArrangementsCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                    deleteFlowerArrangementsCommand.ExecuteNonQuery();
                }

                using (SqlCommand deleteEquipmentsCommand = new SqlCommand(deleteEquipmentsQuery, db))
                {
                    deleteEquipmentsCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                    deleteEquipmentsCommand.ExecuteNonQuery();
                }

                // Now delete the main CustomizePackage record
                using (SqlCommand deleteCustomizePackageCommand = new SqlCommand(deleteCustomizePackageQuery, db))
                {
                    deleteCustomizePackageCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                    deleteCustomizePackageCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting customize package: " + ex.Message, "Deletion Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
    public class FlowerArrangement
    {
        public int ArrangementID { get; set; }
        public string FlowerArrangementName { get; set; }
        public int Quantity { get; set; }
        public string Additional { get; set; }
        public decimal PricePerUnit { get; set; }
    }
    public class Equipment
    {
        public int EquipmentID { get; set; }  
        public string EquipmentName { get; set; }
        public string EquipmentType { get; set; }
        public int Quantity { get; set; }
    }

    public class Cemetery
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public override string ToString()
        {
            return Name; 
        }
    }

    public class DocumentType
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}

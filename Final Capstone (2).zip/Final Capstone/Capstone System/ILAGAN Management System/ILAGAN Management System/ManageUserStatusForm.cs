﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ManageUserStatus : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler UpdateStatus;

        public ManageUserStatus()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadStatusOptions();
        }

        private void LoadStatusOptions()
        {
            try
            {
                db.Open();
                cmb_Status.Items.Clear();
                string query = "SELECT StatusName FROM UserStatus";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cmb_Status.Items.Add(reader["StatusName"].ToString());
                }

                cmb_Status.DropDownStyle = ComboBoxStyle.DropDownList;
                cmb_Status.FormattingEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading statuses: " + ex.Message);
            }
            finally
            {
                if (db.State == System.Data.ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private void btn_UpdateStatus_Click(object sender, EventArgs e)
        {
            try
            {
                if (db.State == ConnectionState.Closed)
                {
                    db.Open();
                }

                string checkAdminQuery = @"
                SELECT COUNT(*) 
                FROM Users u
                INNER JOIN UserAccessLevels ual ON u.UserID = ual.UserID
                INNER JOIN AccessLevels al ON ual.AccessLevelID = al.AccessLevelID
                WHERE u.Username = @Username AND al.AccessLevelName = 'Admin'";

                SqlCommand checkAdminCommand = new SqlCommand(checkAdminQuery, db);
                checkAdminCommand.Parameters.AddWithValue("@Username", txtUsername.Text);

                int isAdmin = (int)checkAdminCommand.ExecuteScalar();

                if (isAdmin > 0 && cmb_Status.Text.ToLower() == "inactive")
                {
                    string countActiveAdminsQuery = @" SELECT COUNT(*)  FROM Users u
                    INNER JOIN UserAccessLevels ual ON u.UserID = ual.UserID
                    INNER JOIN AccessLevels al ON ual.AccessLevelID = al.AccessLevelID
                    WHERE al.AccessLevelName = 'Admin' AND u.StatusID = 
                    (SELECT StatusID FROM UserStatus WHERE StatusName = 'Active')";

                    SqlCommand countActiveAdminsCommand = new SqlCommand(countActiveAdminsQuery, db);
                    int activeAdminCount = (int)countActiveAdminsCommand.ExecuteScalar();


                    if (activeAdminCount <= 1)
                    {
                        MessageBox.Show("At least one admin account must remain active.", "Action Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }


                string query = @"UPDATE Users  SET StatusID = (SELECT StatusID FROM UserStatus WHERE StatusName = @Status)  WHERE Username = @Username";
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@Status", cmb_Status.Text);
                command.Parameters.AddWithValue("@Username", txtUsername.Text);

                int result = command.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("User status updated successfully.");
                    UpdateStatus?.Invoke(this, EventArgs.Empty);
                }
                else
                {
                    MessageBox.Show("User not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating the status: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }
    }
}

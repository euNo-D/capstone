﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ForgotPassword : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public ForgotPassword()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btn_Verify_Click(object sender, EventArgs e)
        {
            string username = txt_Username.Text;
            string answer = txt_SecurityAnswer.Text;
            string number = txt_PhoneNumber.Text;


            // Validate if the username is entered
            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Please enter your username before attempting to recover your password.",
                                "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Query to check if the username exists and its activation status
                string query = @"SELECT StatusID 
                         FROM Users 
                         WHERE Username COLLATE Latin1_General_BIN = @Username";

                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@Username", username);

                y.Open();

                SqlDataReader dr = command.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    string status = dr["StatusID"].ToString();

                    if (status != "1")
                    {
                        MessageBox.Show("This account is deactivated. Password recovery is not allowed.",
                                        "Deactivated Account", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        dr.Close();
                        return;
                    }
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                y.Close();
            }


            if (!ValidateUsername(username) || !ValidateSecurityAnswer(answer) || !ValidatePhoneNumber(number))
            {
                return;
            }

            string verificationResult = VerifyUserDetails(username, answer, number);

            if (verificationResult == "Success")
            {
                ResetPassword resetPasswordForm = new ResetPassword(username, this);
                resetPasswordForm.ShowDialog();
            }
            else
            {
                MessageBox.Show(verificationResult, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool ValidateUsername(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Username is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_Username.Focus();
                return false;
            }
            return true;
        }
        private bool ValidateSecurityAnswer(string answer)
        {
            if (string.IsNullOrEmpty(answer))
            {
                MessageBox.Show("Security answer is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_SecurityAnswer.Focus();
                return false;
            }
            return true;
        }
        private bool ValidatePhoneNumber(string number)
        {
            if (string.IsNullOrEmpty(number))
            {
                MessageBox.Show("Phone number is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_PhoneNumber.Focus();
                return false;
            }

            if (!number.All(char.IsDigit))
            {
                MessageBox.Show("Phone number should contain only numbers.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_PhoneNumber.Focus();
                return false;
            }

            if (number.Length != 11) 
            {
                MessageBox.Show("Phone number must be exactly 11 digits.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_PhoneNumber.Focus();
                return false;
            }

            return true;
        }
        private string VerifyUserDetails(string username, string answer, string phoneNumber)
        {
            string usernameQuery = "SELECT COUNT(1) FROM Users WHERE Username = @Username";
            SqlCommand cmd = new SqlCommand(usernameQuery, db);
            cmd.Parameters.AddWithValue("@Username", username);

            y.Open();
            int usernameExists = Convert.ToInt32(cmd.ExecuteScalar());
            y.Close();

            if (usernameExists == 0)
            {
                return "Username not found. Please try again.";
            }

            // Step 2: Check if the security answer matches the username
            string answerQuery = "SELECT COUNT(1) FROM Users WHERE Username = @Username AND SecurityAnswer = @Answer";
            cmd = new SqlCommand(answerQuery, db);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Answer", answer);

            y.Open();
            int answerMatches = Convert.ToInt32(cmd.ExecuteScalar());
            y.Close();

            if (answerMatches == 0)
            {
                return "Incorrect security answer. Please try again.";
            }

            // Step 3: Check if the phone number matches the username and answer
            string phoneQuery = "SELECT COUNT(1) FROM Users WHERE Username = @Username AND SecurityAnswer = @Answer AND Contact_No = @Contact_No";
            cmd = new SqlCommand(phoneQuery, db);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Answer", answer);
            cmd.Parameters.AddWithValue("@Contact_No", phoneNumber);

            y.Open();
            int phoneMatches = Convert.ToInt32(cmd.ExecuteScalar());
            y.Close();

            if (phoneMatches == 0)
            {
                return "Phone number does not match our records. Please try again.";
            }

            return "Success";
        }
    }
}

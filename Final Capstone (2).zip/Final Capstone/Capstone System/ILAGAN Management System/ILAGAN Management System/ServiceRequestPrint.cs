﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class ServiceRequestPrint : Form
    {
        string connectionString = @"Data Source=DIAMZON\SQLEXPRESS01;Initial Catalog=ilagan;Integrated Security=True";

        private int serviceRequestID;
        public ServiceRequestPrint(int requestID)
        {
            InitializeComponent();
            serviceRequestID = requestID;
            PopulateForm();
        }

        private void btn_Print_Click(object sender, EventArgs e)
        {
            print(this.pnl_ServiceContract);
        }

        private void print(Panel pnl)
        {
            PrinterSettings ps = new PrinterSettings();
            pnl_ServiceContract = pnl;
            getprintarea(pnl_ServiceContract);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();
            PopulateForm();
        }

        private void PopulateForm()
        {
            string query = @"SELECT ClientName, DeceasedFName, DeceasedLName, DeceasedMName,
                            ServiceLocation, CemeteryLocation, DateBurial, TimeBurial,CasketName, VehicleName, EmbalmingDays,
                            PackageName, CasketName, VehicleName, SubTotal, 
                            Discount, DiscountRate, DiscountTotal, TotalPrice
                     FROM ServiceRequests 
                     WHERE ServiceRequestID = @ServiceRequestID;";

            using (SqlConnection db = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                    try
                    {
                        db.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            // Populate form fields
                            lbl_Casket.Text = reader["CasketName"].ToString();
                            lbl_Embalming.Text = reader["EmbalmingDays"].ToString();
                            lbl_FuneralCar.Text = reader["VehicleName"].ToString();
                            lbl_ChargeTo.Text = reader["ClientName"].ToString();
                            lbl_DeceasedName.Text = $"{reader["DeceasedFName"]} {reader["DeceasedMName"]} {reader["DeceasedLName"]}";
                            lbl_ServiceLocation.Text = reader["ServiceLocation"].ToString();
                            lbl_Cemetery.Text = reader["CemeteryLocation"].ToString();
                            lbl_DateofBurial.Text = Convert.ToDateTime(reader["DateBurial"]).ToShortDateString();

                            // Service particulars
                            lbl_Casket.Text = reader["CasketName"].ToString();
                            lbl_TotalCharges.Text = reader["SubTotal"].ToString();
                            lbl_Discount.Text = reader["DiscountTotal"].ToString();
                            lbl_TotalPrice.Text = reader["TotalPrice"].ToString();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading data: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }

        private Bitmap memorying;

        private void getprintarea(Panel pnl)
        {
            memorying = new Bitmap(pnl.Width, pnl.Height);
            pnl.DrawToBitmap(memorying, new Rectangle(0, 0, pnl.Width, pnl.Height));
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(memorying, (pagearea.Width / 2) - (this.pnl_ServiceContract.Width / 2), this.pnl_ServiceContract.Location.Y);
        }
    }
}
